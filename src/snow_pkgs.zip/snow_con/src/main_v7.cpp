#include <memory>
#include <string>
#include <vector>


#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

#include "std_msgs/msg/float64_multi_array.hpp"
#include "sensor_msgs/msg/joint_state.hpp"

using std::placeholders::_1;

class MinimalSubscriber : public rclcpp::Node
{
  public:

    MinimalSubscriber()
    : Node("minimal_subscriber")
    {
      subscription_ = this->create_subscription<sensor_msgs::msg::JointState>("/joint_states", 10, std::bind(&MinimalSubscriber::topic_callback, this, _1));
      RCLCPP_INFO(this->get_logger(), "subscriber node created");


      //publisher
      publisher_ = this->create_publisher<std_msgs::msg::Float64MultiArray>("/effort_controllers/commands", 10);

      RCLCPP_INFO(this->get_logger(), "publisher node created");

      /*
      int i;

      for (i = 0 ; i < 8 ; i++) 
        commands.data.push_back(0);

      publisher_->publish(commands);
*/
    }


  private:
    void topic_callback(const sensor_msgs::msg::JointState::SharedPtr msg) const
    {
      double t;
      static double tStart = 0;
      static int startFlag = 0;
      static double position = 0;
      static double velocity = 0;
      static int step = 0;
      double rw = 0.044;
	
      static double d[4];
      static double v[4];
      static double tstartmove;

      std_msgs::msg::Float64MultiArray commands;
      //RCLCPP_INFO(this->get_logger(), "I heard: '%s' %e %e", msg->name[0].c_str(),msg->position[0],msg->position[1]);

      t = msg->header.stamp.sec*0.50+msg->header.stamp.nanosec*1e-9 - tStart;

      /*RCLCPP_INFO(this->get_logger(),"%e %e %e %e %e %e %e %e %e",
      t,
      msg->position[0],
      msg->position[1],
      msg->position[2],
      msg->position[3],
      msg->position[4],
      msg->position[5],
      msg->position[6],
      msg->position[7]);
      */

      double pArm[4];
      double vArm[4];
      double pWheel[4];
      double vWheel[4];

      double uArm[4];
      double uWheel[4];

      double check;
      
      pArm[0] = msg->position[1];
      pArm[1] = msg->position[3];
      pArm[2] = msg->position[4];
      pArm[3] = msg->position[6];

      pWheel[0] = msg->position[0];
      pWheel[1] = msg->position[2];
      pWheel[2] = msg->position[5];
      pWheel[3] = msg->position[7];

      vArm[0] = msg->velocity[1];
      vArm[1] = msg->velocity[3];
      vArm[2] = msg->velocity[4];
      vArm[3] = msg->velocity[6];

      vWheel[0] = msg->velocity[0];
      vWheel[1] = msg->velocity[2];
      vWheel[2] = msg->velocity[5];
      vWheel[3] = msg->velocity[7];

      

      
      int i;
      double stopPosition[4];
      double tempTime = 0;
      double consTorq = 0.00;

      if (startFlag == 0) {
        startFlag = 1;
        tStart = t;
        t = 0.00;
      }
	
      
      // robot will rotate axis by 90deg
      if (!step) {

        if (t > 0 && t < 2) {
          velocity = (M_PI/2)/4;
        }
      
        else {
          velocity = 0;
        }
      
        position += 0.01*velocity;



        for (i = 0 ; i < 2 ; i++)
          uWheel[i] = -.3*(pArm[i] - position) - 3*(vArm[i] - velocity);
        for (i = 2 ; i < 4 ; i++)
          uWheel[i] = -(-.3*(pArm[i] - position) - 3*(vArm[i] - velocity));


        for (i = 0 ; i < 4 ; i++)
          uArm[i] = 0; 

        //if (pArm[0] >= M_PI/2)  
         //if (fabs(pArm[0] - M_PI/2) < 0.02)
        if (fabs(pArm[0] - M_PI/2) < 0.02) {
          step = 1;
          tStart = 1; 
        }

        check = fabs(pArm[0] - M_PI/2);

        printf("%lf %d %lf\n",t, step, check);
          
        for (i = 0 ; i < 4 ; i++) {
          d[i] = pWheel[i];
          v[i] = 0.0;
        }
        
        tstartmove = t;

      }
      
      // robot will move forward for 25 units
      else if(step == 1) {

        double s[] = {1,-1,1,-1};

        for(i = 0 ; i < 4 ; i++) {  
          if (t < tstartmove + 10) 
            v[i] = s[i]*1.0/10/rw;
          else
            v[i] = 0;
      
          d[i] = d[i] + 0.01*v[i];
        }
        // move forward after 90deg
        uWheel[0] = -0.1*(pWheel[0]- d[0]) + -0.1*(vWheel[0]- v[0]);
        uWheel[1] = -0.1*(pWheel[1]- d[1]) + -0.1*(vWheel[1]- v[1]);
        uWheel[2] = -0.1*(pWheel[2]- d[2]) + -0.1*(vWheel[2]- v[2]);
        uWheel[3] = -0.1*(pWheel[3]- d[3]) + -0.1*(vWheel[3]- v[3]);
        //printf("%lf %lf %lf\n",t, d[0],v[0]);

        printf("%lf", uWheel[0]);

/*        uWheel[0] = -0*((pArm[0] - M_PI/2) - 3*(vArm[0] - 0)) + -1*(pWheel[0]-d/rw) + -1*(vWheel[0]-v/rw);
        uWheel[1] = -0*((pArm[1] - M_PI/2) - 3*(vArm[1] - 0)) + -1;
        uWheel[2] = -0*((pArm[2] - M_PI/2) - 3*(vArm[2] - 0)) + 1;
        uWheel[3] = -0*((pArm[3] - M_PI/2) - 3*(vArm[3] - 0)) + -1;
*/
        for (i = 0 ; i < 4 ; i++)
          uArm[i] = -2*(pArm[i] - M_PI/2) - 2*(vArm[i] - 0); 

        
        /*
        // turn around
        uWheel[0] = -1*(pArm[0] - M_PI/4) - 3*(vArm[0] - 0) + 1;
        uWheel[1] = -1*(pArm[1] - M_PI/4) - 3*(vArm[1] - 0) + -1;
        uWheel[2] = -(-1*(pArm[2] - M_PI/4) - 3*(vArm[2] - 0)) + -1;
        uWheel[3] = -(-1*(pArm[3] - M_PI/4) - 3*(vArm[3] - 0)) + 1; 

        for (i = 0 ; i < 4 ; i++)
          uArm[i] = -2*(pArm[i] - M_PI/4) - 2*(vArm[i] - 0); 
      */

        //if (pWheel[0] >= 25) {
        if (t >= tstartmove + 15) {
        
          //step = 2;
          
          
        }
          

      }

      // robot will attempt to stop
      else if (step ==2 ) {
        
          
          uWheel[0] = -(.17*(vWheel[0] - -2) ) ;
          uWheel[1] =  (.17*(vWheel[0] - -2) ) ;
          uWheel[2] = -(.17*(vWheel[0] - -2) ) ;
          uWheel[3] =  (.17*(vWheel[0] - -2) ) ; 

          /*
          uWheel[0] = -1;
          uWheel[1] = 1;
          uWheel[2] = -1;
          uWheel[3] = 1;  */

          for (i = 0 ; i < 4 ; i++)
            uArm[i] = -2*(pArm[i] - M_PI/2) - 2*(vArm[i] - 0); 

          if (vWheel[0] <= 0) {
            step = 3;
            tempTime = t;
            /*
            for (i = 0 ; i < 4 ; i++) {
              stopPosition[i] = pWheel[i];
              
            } */
            
          }

      }

      // robot will stop for 2 seconds
      else if (step == 3 ) {
        
        /*
          uWheel[0] = -.3*(vWheel[0] - 0) ;
          uWheel[1] = -.3*(vWheel[1] - 0) ;
          uWheel[2] = .3*(vWheel[2] - 0) ;
          uWheel[3] = .3*(vWheel[3] - 0) ; */

          uWheel[0] = -(.17*(vWheel[0] - 0) ) ;
          uWheel[1] =  (.17*(vWheel[0] - 0) ) ;
          uWheel[2] = -(.17*(vWheel[0] - 0) ) ;
          uWheel[3] =  (.17*(vWheel[0] - 0) ) ; 

          for (i = 0 ; i < 4 ; i++)
            uArm[i] = -2*(pArm[i] - M_PI/2) - 2*(vArm[i] - 0); 

          if (tempTime + 2 <= t) {
            tempTime = t;
            step = 4;
            velocity = 0;
            position = 0;
          }
        
      }

      // robot arms will change to 45deg (NOT FINISHED)
      else if (step == 4 ) {
        
        if (t > tempTime && t < tempTime + 2) {
          velocity = 0; //-(M_PI/4)/4;
        }
      
        else {
          velocity = 0;
        }
      
        position = M_PI/4; // += 0.01*velocity;
        
        uWheel[0] =  (-1*(pArm[0] - position) - 3*(vArm[0] - velocity));
        uWheel[1] =  (-1*(pArm[1] - position) - 3*(vArm[1] - velocity));
        uWheel[2] = -(-1*(pArm[2] - position) - 3*(vArm[2] - velocity));
        uWheel[3] = -(-1*(pArm[3] - position) - 3*(vArm[3] - velocity)); 


        for (i = 0 ; i < 4 ; i++)
          //uArm[i] = 0; 
          uArm[i] = -2*(pArm[i] - M_PI/4) - 2*(vArm[i] - 0); 

        if (pArm[0] <= M_PI/4) {
        //if (t >= tempTime + 8) {
          tempTime = t;
          velocity = 0;
          position = 0;
          step = 5;
          //tStart = 1;
          for (i = 0 ; i < 4 ; i++) {
              stopPosition[i] = pWheel[i];
              
            }
        }
        
      }

      // robot will spin 360 degs
      else if (step == 5 ) {
        
        /*
        if (t > tempTime && t < tempTime + 6) {
          // distance to circle around in radians: 135.36
          velocity = 22.56; // 135.36 / 6 seconds = 22.56
        }
      
        else {
          velocity = 0;
        }

        position += 0.01*velocity; */

      
        uWheel[0] = -1*(pArm[0] - M_PI/4) - 3*(vArm[0] - 0) + 1; 
        uWheel[1] = -1*(pArm[1] - M_PI/4) - 3*(vArm[1] - 0) + -1;
        uWheel[2] = -(-1*(pArm[2] - M_PI/4) - 3*(vArm[2] - 0)) + -1;
        uWheel[3] = -(-1*(pArm[3] - M_PI/4) - 3*(vArm[3] - 0)) + 1; 

        for (i = 0 ; i < 4 ; i++)
          uArm[i] = -2*(pArm[i] - M_PI/4) - 2*(vArm[i] - 0); 

        if (pWheel[0] >= stopPosition[0]  +   75) {
          step = 6;
      
        
        }
        
      }

      // robot will attempt to stop
      else if (step == 6 ) {
        
          
          uWheel[0] = -(.17*(vWheel[0] - -1) ) ;
          uWheel[1] = (.17*(vWheel[0] - -1) ) ;
          uWheel[2] = (.17*(vWheel[0] - -1) ) ;
          uWheel[3] = -(.17*(vWheel[0] - -1) ) ; 

          /*
          uWheel[0] = -1;
          uWheel[1] = 1;
          uWheel[2] = -1;
          uWheel[3] = 1;  */

          for (i = 0 ; i < 4 ; i++)
            uArm[i] = -2*(pArm[i] - M_PI/4) - 3*(vArm[i] - 0); 

          if (vWheel[0] <= 0) {
            step = 7;
            tempTime = t;
            
          }

      }

      // robot will stop for 2 seconds
      else if (step == 7 ) {
        
        /*
          uWheel[0] = -.3*(vWheel[0] - 0) ;
          uWheel[1] = -.3*(vWheel[1] - 0) ;
          uWheel[2] = .3*(vWheel[2] - 0) ;
          uWheel[3] = .3*(vWheel[3] - 0) ; */

          uWheel[0] = -(.17*(vWheel[0] - 0) ) ;
          uWheel[1] =  (.17*(vWheel[0] - 0) ) ;
          uWheel[2] = -(.17*(vWheel[0] - 0) ) ;
          uWheel[3] =  (.17*(vWheel[0] - 0) ) ; 

          for (i = 0 ; i < 4 ; i++)
            uArm[i] = -2*(pArm[i] - M_PI/2) - 2*(vArm[i] - 0); 

          if (tempTime + 2 <= t) {
            tempTime = t;
            //step = 4;
            velocity = 0;
            position = 0;
          }
        
      }

      // for (i = 0 ; i < 4 ; i++)
      //    uWheel[i] += -0.3*vArm[i];

      commands.data.push_back(uArm[0]);
      commands.data.push_back(uArm[1]);
      commands.data.push_back(uArm[2]);
      commands.data.push_back(uArm[3]);
      commands.data.push_back( uWheel[0] );
      commands.data.push_back( uWheel[1] );
      commands.data.push_back( uWheel[2] );
      commands.data.push_back( uWheel[3]); 


      publisher_->publish(commands);
          
                    
    /*	commands.data.push_back( 1 ); 
      commands.data.push_back( 1 );
      commands.data.push_back( (pArm[0] >= 1.57080) ? 1 : -1 );
      commands.data.push_back( (pArm[1] >= 1.57080) ? 1 : -1 );*/
      
     // publisher_->publish(commands);

    }
    // Declaration of subscription_ attribute
    rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr subscription_;
    // Declaration of the publisher_ attribute
    rclcpp::Publisher<std_msgs::msg::Float64MultiArray>::SharedPtr publisher_;

};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<MinimalSubscriber>());
  rclcpp::shutdown();

  return 0;
}